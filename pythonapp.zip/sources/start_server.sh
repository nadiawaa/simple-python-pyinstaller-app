#!/bin/bash
# cd /home/ec2-user/simple-python-pyinstaller-app/sources/
python3 add2vals.py X Y
