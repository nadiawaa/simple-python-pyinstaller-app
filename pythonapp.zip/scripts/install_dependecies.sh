#!/bin/bash
# This file is scripts/install_dependencies.sh

pip3 install -r /home/ec2-user/scripts/requirements.txt